﻿namespace MovieRentalFinalProject
{
    partial class SubtitleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SubtitleForm));
            System.Windows.Forms.Label subtitleIDLabel;
            System.Windows.Forms.Label movieIDLabel;
            System.Windows.Forms.Label languageLabel;
            System.Windows.Forms.Label authorLabel;
            this.movieRentalDataSet = new MovieRentalFinalProject.MovieRentalDataSet();
            this.subtitleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.subtitleTableAdapter = new MovieRentalFinalProject.MovieRentalDataSetTableAdapters.SubtitleTableAdapter();
            this.tableAdapterManager = new MovieRentalFinalProject.MovieRentalDataSetTableAdapters.TableAdapterManager();
            this.subtitleBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.subtitleBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.subtitleDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subtitleIDTextBox = new System.Windows.Forms.TextBox();
            this.movieIDTextBox = new System.Windows.Forms.TextBox();
            this.languageTextBox = new System.Windows.Forms.TextBox();
            this.authorTextBox = new System.Windows.Forms.TextBox();
            subtitleIDLabel = new System.Windows.Forms.Label();
            movieIDLabel = new System.Windows.Forms.Label();
            languageLabel = new System.Windows.Forms.Label();
            authorLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.movieRentalDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.subtitleBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.subtitleBindingNavigator)).BeginInit();
            this.subtitleBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.subtitleDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // movieRentalDataSet
            // 
            this.movieRentalDataSet.DataSetName = "MovieRentalDataSet";
            this.movieRentalDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // subtitleBindingSource
            // 
            this.subtitleBindingSource.DataMember = "Subtitle";
            this.subtitleBindingSource.DataSource = this.movieRentalDataSet;
            // 
            // subtitleTableAdapter
            // 
            this.subtitleTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.ActorTableAdapter = null;
            this.tableAdapterManager.AdminTableAdapter = null;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BELONGS_TOTableAdapter = null;
            this.tableAdapterManager.GenreTableAdapter = null;
            this.tableAdapterManager.MovieTableAdapter = null;
            this.tableAdapterManager.RENTSTableAdapter = null;
            this.tableAdapterManager.STARS_INTableAdapter = null;
            this.tableAdapterManager.SubtitleTableAdapter = this.subtitleTableAdapter;
            this.tableAdapterManager.UpdateOrder = MovieRentalFinalProject.MovieRentalDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.UserTableAdapter = null;
            // 
            // subtitleBindingNavigator
            // 
            this.subtitleBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.subtitleBindingNavigator.BindingSource = this.subtitleBindingSource;
            this.subtitleBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.subtitleBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.subtitleBindingNavigator.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.subtitleBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.subtitleBindingNavigatorSaveItem});
            this.subtitleBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.subtitleBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.subtitleBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.subtitleBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.subtitleBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.subtitleBindingNavigator.Name = "subtitleBindingNavigator";
            this.subtitleBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.subtitleBindingNavigator.Size = new System.Drawing.Size(900, 27);
            this.subtitleBindingNavigator.TabIndex = 0;
            this.subtitleBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(24, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(24, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(45, 20);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(24, 24);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // subtitleBindingNavigatorSaveItem
            // 
            this.subtitleBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.subtitleBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("subtitleBindingNavigatorSaveItem.Image")));
            this.subtitleBindingNavigatorSaveItem.Name = "subtitleBindingNavigatorSaveItem";
            this.subtitleBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.subtitleBindingNavigatorSaveItem.Text = "Save Data";
            this.subtitleBindingNavigatorSaveItem.Click += new System.EventHandler(this.SubtitleBindingNavigatorSaveItem_Click);
            // 
            // subtitleDataGridView
            // 
            this.subtitleDataGridView.AutoGenerateColumns = false;
            this.subtitleDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.subtitleDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.subtitleDataGridView.DataSource = this.subtitleBindingSource;
            this.subtitleDataGridView.Location = new System.Drawing.Point(332, 73);
            this.subtitleDataGridView.Name = "subtitleDataGridView";
            this.subtitleDataGridView.RowTemplate.Height = 24;
            this.subtitleDataGridView.Size = new System.Drawing.Size(450, 220);
            this.subtitleDataGridView.TabIndex = 1;
            this.subtitleDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.SubtitleDataGridView_CellContentClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "SubtitleID";
            this.dataGridViewTextBoxColumn1.HeaderText = "SubtitleID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "MovieID";
            this.dataGridViewTextBoxColumn2.HeaderText = "MovieID";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Language";
            this.dataGridViewTextBoxColumn3.HeaderText = "Language";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Author";
            this.dataGridViewTextBoxColumn4.HeaderText = "Author";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // subtitleIDLabel
            // 
            subtitleIDLabel.AutoSize = true;
            subtitleIDLabel.Location = new System.Drawing.Point(48, 89);
            subtitleIDLabel.Name = "subtitleIDLabel";
            subtitleIDLabel.Size = new System.Drawing.Size(76, 17);
            subtitleIDLabel.TabIndex = 2;
            subtitleIDLabel.Text = "Subtitle ID:";
            // 
            // subtitleIDTextBox
            // 
            this.subtitleIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.subtitleBindingSource, "SubtitleID", true));
            this.subtitleIDTextBox.Location = new System.Drawing.Point(130, 86);
            this.subtitleIDTextBox.Name = "subtitleIDTextBox";
            this.subtitleIDTextBox.Size = new System.Drawing.Size(100, 22);
            this.subtitleIDTextBox.TabIndex = 3;
            // 
            // movieIDLabel
            // 
            movieIDLabel.AutoSize = true;
            movieIDLabel.Location = new System.Drawing.Point(48, 117);
            movieIDLabel.Name = "movieIDLabel";
            movieIDLabel.Size = new System.Drawing.Size(66, 17);
            movieIDLabel.TabIndex = 4;
            movieIDLabel.Text = "Movie ID:";
            // 
            // movieIDTextBox
            // 
            this.movieIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.subtitleBindingSource, "MovieID", true));
            this.movieIDTextBox.Location = new System.Drawing.Point(130, 114);
            this.movieIDTextBox.Name = "movieIDTextBox";
            this.movieIDTextBox.Size = new System.Drawing.Size(100, 22);
            this.movieIDTextBox.TabIndex = 5;
            // 
            // languageLabel
            // 
            languageLabel.AutoSize = true;
            languageLabel.Location = new System.Drawing.Point(48, 145);
            languageLabel.Name = "languageLabel";
            languageLabel.Size = new System.Drawing.Size(76, 17);
            languageLabel.TabIndex = 6;
            languageLabel.Text = "Language:";
            // 
            // languageTextBox
            // 
            this.languageTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.subtitleBindingSource, "Language", true));
            this.languageTextBox.Location = new System.Drawing.Point(130, 142);
            this.languageTextBox.Name = "languageTextBox";
            this.languageTextBox.Size = new System.Drawing.Size(100, 22);
            this.languageTextBox.TabIndex = 7;
            // 
            // authorLabel
            // 
            authorLabel.AutoSize = true;
            authorLabel.Location = new System.Drawing.Point(48, 173);
            authorLabel.Name = "authorLabel";
            authorLabel.Size = new System.Drawing.Size(54, 17);
            authorLabel.TabIndex = 8;
            authorLabel.Text = "Author:";
            // 
            // authorTextBox
            // 
            this.authorTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.subtitleBindingSource, "Author", true));
            this.authorTextBox.Location = new System.Drawing.Point(130, 170);
            this.authorTextBox.Name = "authorTextBox";
            this.authorTextBox.Size = new System.Drawing.Size(100, 22);
            this.authorTextBox.TabIndex = 9;
            // 
            // SubtitleForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 450);
            this.Controls.Add(subtitleIDLabel);
            this.Controls.Add(this.subtitleIDTextBox);
            this.Controls.Add(movieIDLabel);
            this.Controls.Add(this.movieIDTextBox);
            this.Controls.Add(languageLabel);
            this.Controls.Add(this.languageTextBox);
            this.Controls.Add(authorLabel);
            this.Controls.Add(this.authorTextBox);
            this.Controls.Add(this.subtitleDataGridView);
            this.Controls.Add(this.subtitleBindingNavigator);
            this.Name = "SubtitleForm";
            this.Text = "SubtitleForm";
            this.Load += new System.EventHandler(this.SubtitleForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.movieRentalDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.subtitleBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.subtitleBindingNavigator)).EndInit();
            this.subtitleBindingNavigator.ResumeLayout(false);
            this.subtitleBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.subtitleDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MovieRentalDataSet movieRentalDataSet;
        private System.Windows.Forms.BindingSource subtitleBindingSource;
        private MovieRentalDataSetTableAdapters.SubtitleTableAdapter subtitleTableAdapter;
        private MovieRentalDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator subtitleBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton subtitleBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView subtitleDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.TextBox subtitleIDTextBox;
        private System.Windows.Forms.TextBox movieIDTextBox;
        private System.Windows.Forms.TextBox languageTextBox;
        private System.Windows.Forms.TextBox authorTextBox;
    }
}