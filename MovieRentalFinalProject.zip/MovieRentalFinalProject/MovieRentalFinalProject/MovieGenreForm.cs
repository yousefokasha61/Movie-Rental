﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieRentalFinalProject
{
    public partial class MovieGenreForm : Form
    {
        public MovieGenreForm()
        {
            InitializeComponent();
        }

        private void BELONGS_TOBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.bELONGS_TOBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.movieRentalDataSet);

        }

        private void MovieGenreForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'movieRentalDataSet.BELONGS_TO' table. You can move, or remove it, as needed.
            this.bELONGS_TOTableAdapter.Fill(this.movieRentalDataSet.BELONGS_TO);

        }
    }
}
