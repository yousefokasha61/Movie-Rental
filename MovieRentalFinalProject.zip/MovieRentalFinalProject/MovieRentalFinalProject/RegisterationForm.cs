﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieRentalFinalProject
{
    public partial class RegisterationForm : Form
    {
        private void doQuery(string q)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-9TIH3PF;Initial Catalog=MovieRental;Integrated Security=True");
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.Open();
            cmd.CommandText = q;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public RegisterationForm()
        {
            InitializeComponent();
        }

        private void UserBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.userBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.movieRentalDataSet);

        }

        private void RegisterationForm_Load(object sender, EventArgs e)
        {

        }

        private void UserDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void BindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
        }

        private void ToolStripButton1_Click(object sender, EventArgs e)
        {

        }

        private void InsertButton_Click(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'movieRentalDataSet.User' table. You can move, or remove it, as needed.
            this.userTableAdapter.Fill(this.movieRentalDataSet.User);

        }

        private void UserEmailTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button1_Click_1(object sender, EventArgs e)
        {
            string q;
            q = "INSERT Into [User] VALUES(" + idText.Text + " , '" + emailText.Text + "' , '" + creditText.Text + "' , '"
                + dateTimePicker1.Text + "' , '" + countryText.Text + "' , '" + nameText.Text + "')";
            doQuery(q);
            this.userTableAdapter.Fill(this.movieRentalDataSet.User);

        }

        private void Label6_Click(object sender, EventArgs e)
        {

        }

        private void UpdateButton_Click(object sender, EventArgs e)
        {
            string q = "Update [User] SET ";
            bool prev = false;
            if (!String.IsNullOrEmpty(emailText.Text))
                q = addConditionUpdate(q, "UserEmail", "'" + emailText.Text + "'", ref prev);
            if (!String.IsNullOrEmpty(creditText.Text))
                q = addConditionUpdate(q, "creditCard", "'" + creditText.Text + "'", ref prev);
            if (!String.IsNullOrEmpty(dateTimePicker1.Text))
                q = addConditionUpdate(q, "BirthDate", "'" + dateTimePicker1.Text + "'", ref prev);
            if (!String.IsNullOrEmpty(countryText.Text))
                q = addConditionUpdate(q, "userCountry", "'" + countryText.Text + "'", ref prev);
            if (!String.IsNullOrEmpty(nameText.Text))
                q = addConditionUpdate(q, "userName", "'" + nameText.Text + "'", ref prev);

            q += " WHERE UserID = " + idText.Text;
            doQuery(q);
            this.userTableAdapter.Fill(this.movieRentalDataSet.User);

        }
        private string addConditionUpdate(string q, string attName, string attValue, ref bool prev)
        {
            if (prev)
                q += " , ";
            q += attName + " = " + attValue + " ";
            prev = true;
            return q;
        }
        private string addCondition(string q, string attName, string attValue, ref bool prev)
        {
            if (prev)
                q += " AND ";
            else
                q += " WHERE ";
            q += attName + " = " + attValue + " ";
            prev = true;
            return q;
        }
        private void Button1_Click_2(object sender, EventArgs e)
        {
            string q = "DELETE  from [User] ";
            bool prev = false;
            if (!String.IsNullOrEmpty(idText.Text))
                q = addCondition(q, "UserID", idText.Text, ref prev);
            if (!String.IsNullOrEmpty(emailText.Text))
                q = addCondition(q, "UserEmail", "'" + emailText.Text + "'", ref prev);
            if (!String.IsNullOrEmpty(creditText.Text))
                q = addCondition(q, "creditCard", "'" + creditText.Text + "'", ref prev);
            if (!String.IsNullOrEmpty(dateTimePicker1.Text))
                q = addCondition(q, "BirthDate", "'" + dateTimePicker1.Text + "'", ref prev);
            if (!String.IsNullOrEmpty(countryText.Text))
                q = addCondition(q, "userCountry", "'" + countryText.Text + "'", ref prev);
            if (!String.IsNullOrEmpty(nameText.Text))
                q = addCondition(q, "userName", "'" + nameText.Text + "'", ref prev);
            doQuery(q);
            this.userTableAdapter.Fill(this.movieRentalDataSet.User);

        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            this.userTableAdapter.Fill(this.movieRentalDataSet.User);

        }
    }
}
