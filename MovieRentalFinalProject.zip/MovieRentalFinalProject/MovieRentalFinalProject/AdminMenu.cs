﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieRentalFinalProject
{
    public partial class AdminMenu : Form
    {
        public AdminMenu()
        {
            InitializeComponent();
        }

        private void RegisterButton_Click(object sender, EventArgs e)
        {
            AdminRegisterationForm f = new AdminRegisterationForm();
            f.Show();
            this.Hide();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            MoviesForm f = new MoviesForm();
            f.Show();
            this.Hide();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            ActorForm f = new ActorForm();
            f.Show();
            this.Hide();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            SubtitleForm f = new SubtitleForm();
            f.Show();
            this.Hide();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            MovieCrewForm f = new MovieCrewForm();
            f.Show();
            this.Hide();
        }

        private void AddGenreButton_Click(object sender, EventArgs e)
        {
            GenreForm f = new GenreForm();
            f.Show();
            this.Hide();
        }

        private void MovieGenreButton_Click(object sender, EventArgs e)
        {
            MovieGenreForm f = new MovieGenreForm();
            f.Show();
            this.Hide();
        }
    }
}
