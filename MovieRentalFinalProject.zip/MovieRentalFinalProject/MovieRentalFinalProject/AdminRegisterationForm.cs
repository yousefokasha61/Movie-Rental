﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieRentalFinalProject
{
    public partial class AdminRegisterationForm : Form
    {
        private void doQuery(string q)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-9TIH3PF;Initial Catalog=MovieRental;Integrated Security=True");
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.Open();
            cmd.CommandText = q;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public AdminRegisterationForm()
        {
            InitializeComponent();
        }

        private void RegisterButton_Click(object sender, EventArgs e)
        {
            string q;
            q = "Insert into [Admin] Values (";
            q += idText.Text;
            q += " ,'" + emailText.Text + "' ";
            q += " ,'" + nameText.Text + "') ";
            doQuery(q);
            this.adminTableAdapter.Fill(this.movieRentalDataSet.Admin);
        }

        private void UpdateButton_Click(object sender, EventArgs e)
        {
            string q = "Update [Admin] SET ";
            bool prev = false;
            if (!String.IsNullOrEmpty(emailText.Text))
                q = addConditionUpdate(q, "AdminEmail", "'" + emailText.Text + "'", ref prev);
            if (!String.IsNullOrEmpty(nameText.Text))
                q = addConditionUpdate(q, "adminName", "'" + nameText.Text + "'", ref prev);
            q += " WHERE AdminID = " + idText.Text;
            doQuery(q);
            this.adminTableAdapter.Fill(this.movieRentalDataSet.Admin);

        }

        private string addConditionUpdate(string q, string attName, string attValue, ref bool prev)
        {
            if (prev)
                q += " , ";
            q += attName + " = " + attValue + " ";
            prev = true;
            return q;
        }
        private string addCondition(string q, string attName, string attValue, ref bool prev)
        {
            if (prev)
                q += " AND ";
            else
                q += " WHERE ";
            q += attName + " = " + attValue + " ";
            prev = true;
            return q;
        }
        private void DeleteButton_Click(object sender, EventArgs e)
        {
            string q = "DELETE  from [Admin] ";
            bool prev = false;
            if (!String.IsNullOrEmpty(idText.Text))
                q = addCondition(q, "AdminID", idText.Text, ref prev);
            if (!String.IsNullOrEmpty(nameText.Text))
                q = addCondition(q, "adminName", "'" + nameText.Text + "'", ref prev);
            if (!String.IsNullOrEmpty(emailText.Text))
                q = addCondition(q, "AdminEmail", "'" + emailText.Text + "'", ref prev);
            doQuery(q);
            this.adminTableAdapter.Fill(this.movieRentalDataSet.Admin);

        }

        private void AdminRegisterationForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'movieRentalDataSet.Admin' table. You can move, or remove it, as needed.
            this.adminTableAdapter.Fill(this.movieRentalDataSet.Admin);

        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
