﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieRentalFinalProject
{
    public partial class BrowseMoviesForm : Form
    {
        public BrowseMoviesForm()
        {
            InitializeComponent();
        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }

        private void Label3_Click(object sender, EventArgs e)
        {

        }

        private void showQuery(string q, string tableName)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-9TIH3PF;Initial Catalog=MovieRental;Integrated Security=True");
            con.Open();
            SqlDataAdapter sd = new SqlDataAdapter(q, con);
            /*
            DataSet ds = new DataSet();
            sd.Fill(ds, tableName);
            dataGridView1.DataSource = ds.Tables[0];
            */
            DataTable dt = new DataTable();
            sd.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private string Join(string q, string tableName)
        {
            q += " , " + tableName + " ";
            return q;
        }
        private string addCondition(string q, string attName, string attValue, ref bool prev)
        {
            if (prev)
                q += " AND ";
            else
                q += " WHERE ";
            q += attName + " = " + attValue + " ";
            prev = true;
            return q;
        }
        private string addJoinCondition(string q, string table1, string middleTable, string table2, string joinAtt1, string JoinAtt2, ref bool prev)
        {
            if (prev)
                q += " AND ";
            else
                q += " WHERE ";
            q += table1 + "." + joinAtt1 + " = " + middleTable + "." + joinAtt1 + " ";
            q += " AND ";
            q += table2 + "." + JoinAtt2 + " = " + middleTable + "." + JoinAtt2 + " ";
            prev = true;
            return q;
        }
         
        private void BtnShow_Click(object sender, EventArgs e)
        {
            string q = "Select * From Movie ";
            if (!String.IsNullOrEmpty(txtGenre.Text))
            {
                q = Join(q, "Genre");
                q = Join(q, "BELONGS_TO");
            }
            if (!String.IsNullOrEmpty(txtActor.Text))
            {
                q = Join(q, "Actor");
                q = Join(q, "STARS_IN");
            }
            bool prev = false;
            if (!String.IsNullOrEmpty(txtID.Text))
                q = addCondition(q, "MovieID", txtID.Text, ref prev);
            if (!String.IsNullOrEmpty(txtDate.Text))
                q = addCondition(q, "PublishDate", "'" + txtDate.Text + "'", ref prev);
            if (!String.IsNullOrEmpty(txtCountry.Text))
                q = addCondition(q, "movieCountry", "'" + txtCountry.Text + "'", ref prev);
            if (!String.IsNullOrEmpty(txtName.Text))
                q = addCondition(q, "movieName", "'" + txtName.Text + "'", ref prev);
            if (!String.IsNullOrEmpty(txtGenre.Text))
            {
                q = addJoinCondition(q, "Movie", "BELONGS_TO", "Genre", "MovieID", "GenreCode", ref prev);
                q = addCondition(q, "GenreName", "'" + txtGenre.Text + "'", ref prev);
            }
            if (!String.IsNullOrEmpty(txtActor.Text))
            {
                q = addJoinCondition(q, "Movie", "STARS_IN", "Actor", "MovieID", "ActorID", ref prev);
                q = addCondition(q, "Name", "'" + txtActor.Text + "'", ref prev);
            }
            showQuery(q, "Movie");
        }
    }
}
