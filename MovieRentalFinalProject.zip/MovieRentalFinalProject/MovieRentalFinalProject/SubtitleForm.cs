﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieRentalFinalProject
{
    public partial class SubtitleForm : Form
    {
        public SubtitleForm()
        {
            InitializeComponent();
        }

        private void SubtitleBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.subtitleBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.movieRentalDataSet);

        }

        private void SubtitleForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'movieRentalDataSet.Subtitle' table. You can move, or remove it, as needed.
            this.subtitleTableAdapter.Fill(this.movieRentalDataSet.Subtitle);

        }

        private void SubtitleDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
