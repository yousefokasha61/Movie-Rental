﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieRentalFinalProject
{
    public partial class MovieCrewForm : Form
    {
        public MovieCrewForm()
        {
            InitializeComponent();
        }

        private void STARS_INBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.sTARS_INBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.movieRentalDataSet);

        }

        private void MovieCrewForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'movieRentalDataSet.STARS_IN' table. You can move, or remove it, as needed.
            this.sTARS_INTableAdapter.Fill(this.movieRentalDataSet.STARS_IN);

        }
    }
}
