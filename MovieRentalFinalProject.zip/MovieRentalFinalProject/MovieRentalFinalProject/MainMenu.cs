﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieRentalFinalProject
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        private void GoToUserMenuButton_Click(object sender, EventArgs e)
        {
            UserMenu userMenuObject = new UserMenu();
            userMenuObject.Show();
            this.Hide();
        }

        private void GoToAdminMenuButton_Click(object sender, EventArgs e)
        {
            AdminMenu adminMenuObject = new AdminMenu();
            adminMenuObject.Show();
            this.Hide();

        }
    }
}
