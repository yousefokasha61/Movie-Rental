﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieRentalFinalProject
{
    public partial class UserMenu : Form
    {
        public UserMenu()
        {
            InitializeComponent();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void RegisterButton_Click(object sender, EventArgs e)
        {
            RegisterationForm registerationMenuObject = new RegisterationForm();
            registerationMenuObject.Show();
            this.Hide();
        }

        private void BrowseButton_Click(object sender, EventArgs e)
        {
            BrowseMoviesForm f = new BrowseMoviesForm();
            f.Show();
            this.Hide();
        
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            RentForm f = new RentForm();
            f.Show();
            this.Hide();
        }
    }
}
