﻿namespace MovieRentalFinalProject
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GoToUserMenuButton = new System.Windows.Forms.Button();
            this.GoToAdminMenuButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // GoToUserMenuButton
            // 
            this.GoToUserMenuButton.Location = new System.Drawing.Point(136, 184);
            this.GoToUserMenuButton.Name = "GoToUserMenuButton";
            this.GoToUserMenuButton.Size = new System.Drawing.Size(109, 68);
            this.GoToUserMenuButton.TabIndex = 0;
            this.GoToUserMenuButton.Text = "Go To User Menu";
            this.GoToUserMenuButton.UseVisualStyleBackColor = true;
            this.GoToUserMenuButton.Click += new System.EventHandler(this.GoToUserMenuButton_Click);
            // 
            // GoToAdminMenuButton
            // 
            this.GoToAdminMenuButton.Location = new System.Drawing.Point(529, 184);
            this.GoToAdminMenuButton.Name = "GoToAdminMenuButton";
            this.GoToAdminMenuButton.Size = new System.Drawing.Size(145, 76);
            this.GoToAdminMenuButton.TabIndex = 1;
            this.GoToAdminMenuButton.Text = "Go To Admin Menu Button";
            this.GoToAdminMenuButton.UseVisualStyleBackColor = true;
            this.GoToAdminMenuButton.Click += new System.EventHandler(this.GoToAdminMenuButton_Click);
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.GoToAdminMenuButton);
            this.Controls.Add(this.GoToUserMenuButton);
            this.Name = "MainMenu";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button GoToUserMenuButton;
        private System.Windows.Forms.Button GoToAdminMenuButton;
    }
}

